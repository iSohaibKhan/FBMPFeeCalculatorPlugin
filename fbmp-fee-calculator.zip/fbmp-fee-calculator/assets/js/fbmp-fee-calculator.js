(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var cfg = window.FbmpCalcData || {};
    var facebookRate = parseFloat(cfg.facebook_fee_rate) || 0.05;
    var defaultBase = parseFloat(cfg.default_base_fee) || 15.0;
    var currencySym = cfg.currency || '$';

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.fbmp-calc'); if(!root) return;
        var email = qs('#fbmp-email', root); var confirmBtn = qs('#fbmp-confirm-email', root); var clearBtn = qs('#fbmp-clear', root);
        var saleType = qs('#fbmp-sale-type', root);
        var saleInput = qs('#fbmp-item-price', root); var costInput = qs('#fbmp-item-cost', root);
        var shipCostInput = qs('#fbmp-shipping-cost', root); var shipChargesInput = qs('#fbmp-shipping-charges', root);

        var results = qs('#fbmp-results', root);
        var resFacebook = qs('#res-facebook', root); var resShipcost = qs('#res-shipcost', root); var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root); var resProfit = qs('#res-profit', root); var resMargin = qs('#res-margin', root);

        function setDisabledState(disabled){ [saleType, saleInput, costInput, shipCostInput, shipChargesInput].forEach(function(i){ if(i) i.disabled = disabled; }); if(disabled){ root.classList.add('fbmp-disabled'); results.style.display='none'; } else { root.classList.remove('fbmp-disabled'); results.style.display='block'; } }

        // restore email
        var savedEmail = localStorage.getItem('fbmp_email') || ''; var confirmed = localStorage.getItem('fbmp_email_confirmed') === '1'; if(savedEmail) email.value = savedEmail; if(confirmed && savedEmail){ confirmBtn.textContent='✔ Email Confirmed'; confirmBtn.disabled=true; setDisabledState(false);} else { setDisabledState(true);}

        function adjustShippingVisibility(){ if(saleType.value === 'Local Pickup (In-Person)'){ // hide shipping inputs
                document.querySelectorAll('.fb-shipping').forEach(function(el){ el.style.display='none'; });
            } else { document.querySelectorAll('.fb-shipping').forEach(function(el){ el.style.display=''; }); }
        }

        saleType.addEventListener('change', function(){ adjustShippingVisibility(); calculate(); });
        [saleInput,costInput,shipCostInput,shipChargesInput].forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        confirmBtn.addEventListener('click', function(){ var val = email.value.trim(); if(!val || !/\S+@\S+\.\S+/.test(val)){ alert('Please enter a valid email to continue'); return; } confirmBtn.textContent='✔ Email Confirmed'; confirmBtn.disabled=true; localStorage.setItem('fbmp_email', val); localStorage.setItem('fbmp_email_confirmed','1'); setDisabledState(false); adjustShippingVisibility(); calculate(); });

        clearBtn.addEventListener('click', function(){ email.value=''; confirmBtn.textContent='Confirm Email'; confirmBtn.disabled=false; localStorage.removeItem('fbmp_email'); localStorage.removeItem('fbmp_email_confirmed'); [saleType,saleInput,costInput,shipCostInput,shipChargesInput].forEach(function(i){ if(i){ if(i.type==='checkbox') i.checked=false; else i.value=''; } }); adjustShippingVisibility(); setDisabledState(true); [resFacebook,resShipcost,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); }); });

        function formatCurrency(val){ if(isNaN(val)) return '-'; return currencySym + Number(val).toFixed(2); }

        function calculate(){ var type = saleType.value || 'Shipping Order'; var sale = parseFloat(saleInput.value) || 0; var cost = parseFloat(costInput.value) || 0; var shipCost = parseFloat(shipCostInput.value); var shipCharges = parseFloat(shipChargesInput.value);
            // default handling
            if(isNaN(shipCost)) shipCost = defaultBase; // if not provided use default base fee
            if(isNaN(shipCharges)) shipCharges = 0;

            var facebookFee = 0; var totalFees = 0;
            if(type === 'Shipping Order'){
                facebookFee = Number((sale * facebookRate).toFixed(2));
                // Shipping cost is considered part of fees
                totalFees = Number((facebookFee + shipCost).toFixed(2));
            } else { // Local Pickup
                facebookFee = 0;
                // For Local Pickup examples a base/platform fee of defaultBase is used
                totalFees = Number((defaultBase).toFixed(2));
                shipCost = 0; shipCharges = 0;
            }

            // Earnings: sale + shipping charges - totalFees
            var earnings = Number((sale + shipCharges - totalFees).toFixed(2));
            // Profit: earnings - item cost
            var profit = Number((earnings - cost).toFixed(2));
            var margin = 0; if(earnings !== 0) margin = Number(((profit / earnings) * 100).toFixed(1));

            resFacebook.textContent = formatCurrency(facebookFee);
            resShipcost.textContent = formatCurrency(shipCost);
            resTotal.textContent = formatCurrency(totalFees);
            resEarnings.textContent = formatCurrency(earnings);
            resProfit.textContent = formatCurrency(profit);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ el.classList.remove('positive','negative'); var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); if(!isNaN(num) && num >= 0) el.classList.add('positive'); else el.classList.add('negative'); });
        }

        adjustShippingVisibility();

    });
})();