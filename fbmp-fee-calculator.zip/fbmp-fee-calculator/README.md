## README / Notes

* **Shortcode**: use `[fbmp_fee_calculator]` in any post/page/widget to show the calculator.
* **Behavior**:

  * Email confirm required before inputs enable; confirmed email persists to `localStorage`.
  * Sale Type `Shipping Order` shows shipping fields and uses Shipping Cost as a fee component; `Local Pickup (In-Person)` hides shipping fields and uses a default base fee (15.00 in examples).
  * **Facebook Fee** = 5% of Item Price when `Shipping Order`, otherwise 0.
  * **Total Fees** = Facebook Fee + Shipping Cost (or base default for local pickup).
  * **Earnings** = Item Price + Shipping Charges − Total Fees.
  * **Profit** = Earnings − Item Cost.
  * **Profit Margin** = Profit / Earnings × 100.
* **Design & theme integration**: CSS intentionally uses `font-family: inherit; color: inherit;` and CSS variables so button color/typography follow the theme/Elementor.
* Change rates/defaults using `add_filter('fbmp_calc_config', function($cfg){ ... return $cfg; });`
