<?php
/*
Plugin Name: FBMP Fee Calculator Shortcode
Plugin URI: https://sellercave.com/fbmp-fee-calculator/
Description: Shortcode [fbmp_fee_calculator] — responsive Facebook Marketplace (FBMP) fee calculator. Inherits theme colors & typography via CSS variables.
Version: 1.0.0
Author: Sohaib S. Khan
Author URI: https://isohaibkhan.github.io/
Text Domain: fbmp-fee-calculator
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function fbmp_register_assets() {
    wp_register_style('fbmp-fee-calculator-css', plugins_url('assets/css/fbmp-fee-calculator.css', __FILE__));
    wp_register_script('fbmp-fee-calculator-js', plugins_url('assets/js/fbmp-fee-calculator.js', __FILE__), array('jquery'), '1.0', true);

    // Default config passed to JS. Filterable.
    $config = array(
        'currency' => '$',
        'facebook_fee_rate' => 0.05, // 5%
        'default_base_fee' => 15.00 // a base/platform fee used in examples
    );

    $config = apply_filters('fbmp_calc_config', $config);

    wp_localize_script('fbmp-fee-calculator-js', 'FbmpCalcData', $config);
}
add_action('wp_enqueue_scripts', 'fbmp_register_assets');

function fbmp_fee_calculator_shortcode($atts = array()){
    wp_enqueue_style('fbmp-fee-calculator-css');
    wp_enqueue_script('fbmp-fee-calculator-js');

    ob_start();
    ?>
    <div class="fbmp-calc" aria-live="polite">
        <div class="card">
            <div class="top-row">
                <label class="label">Your Email <span class="required">*</span></label>
                <div class="email-row">
                    <div class="email-input-wrap">
                        <span class="email-icon">✉️</span>
                        <input id="fbmp-email" type="email" placeholder="Enter your email" aria-label="Your email" />
                    </div>
                    <button id="fbmp-confirm-email" class="btn" type="button">Confirm Email</button>
                    <button id="fbmp-clear" class="btn btn-outline" type="button">Clear All</button>
                </div>
                <p class="help-text">Required for your fee calculation</p>
            </div>

            <div class="grid">
                <div class="form-group full">
                    <label>Sale Type</label>
                    <select id="fbmp-sale-type">
                        <option>Shipping Order</option>
                        <option>Local Pickup (In-Person)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Item Price</label>
                    <input id="fbmp-item-price" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Item Cost</label>
                    <input id="fbmp-item-cost" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group fb-shipping">
                    <label>Shipping Cost</label>
                    <input id="fbmp-shipping-cost" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group fb-shipping">
                    <label>Shipping Charges</label>
                    <input id="fbmp-shipping-charges" type="number" min="0" step="0.01" />
                </div>
            </div>

            <div class="results" id="fbmp-results" aria-hidden="true">
                <div class="result-row"><div class="label">Facebook Fee (5%):</div><div class="value" id="res-facebook">-</div></div>
                <div class="result-row"><div class="label">Shipping Cost:</div><div class="value" id="res-shipcost">-</div></div>
                <div class="result-row total"><div class="label">Total Fees:</div><div class="value" id="res-total">-</div></div>
                <div class="result-row"><div class="label">Your Earnings:</div><div class="value" id="res-earnings">-</div></div>
                <div class="result-row"><div class="label">Your Profit:</div><div class="value" id="res-profit">-</div></div>
                <div class="result-row"><div class="label">Profit Margin:</div><div class="value" id="res-margin">-</div></div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('fbmp_fee_calculator', 'fbmp_fee_calculator_shortcode');
